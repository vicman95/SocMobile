from yoyo import step

step(
    "CREATE TABLE IF NOT EXISTS login (timestamp INTEGER, message TEXT)",
)
